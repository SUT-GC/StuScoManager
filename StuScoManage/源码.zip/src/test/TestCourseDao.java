package test;

import java.util.List;

import dao.CourseDao;
import entity.Course;

public class TestCourseDao {

	public static void main(String[] args) {
//		Course course = new Course("1001", "java 程序设计", 1, "test");
//		int result = CourseDao.insertCourse(course);
//		System.out.println(result);
		List list = CourseDao.selectCourseByName("s");
		for(Object c : list){
			System.out.println(c);
		}
	}

}
