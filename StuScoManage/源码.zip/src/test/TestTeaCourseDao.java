package test;

import dao.TeaCourseDao;
import dao.TeacherDao;
import entity.TeaCourse;

public class TestTeaCourseDao {

	public static void main(String[] args) {
//		TeaCourse teaCourse = new TeaCourse("16001", "1003");
//		int result = TeaCourseDao.insertTeaCourse(teaCourse);
//		System.out.println(result);
		System.out.println(TeaCourseDao.selectTeaCourseById(2));
	}

}
