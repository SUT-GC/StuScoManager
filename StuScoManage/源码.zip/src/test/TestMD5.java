package test;

import util.StringToMD5Util;

public class TestMD5 {

	public static void main(String[] args) {
		System.out.println(StringToMD5Util.toMD5("11111"));
		// TODO Auto-generated method stub

	}

}
